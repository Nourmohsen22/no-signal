
// navbar js
const links = document.querySelectorAll('.nav-links a');
links.forEach(link => {
  link.addEventListener('click', function(e) {
    links.forEach(l => l.classList.remove('active'));
    this.classList.add('active');
  });
});

// Store chart instances
const chartInstances = {
    voltage: null,
    current: null,
    power: null,
    energy: null,
    frequency: null,
    powerFactor: null
};

// Initialize all charts with empty data
function initCharts() {
    const timeLabels = ['12AM', '6AM', '12PM', '6PM'];
    
    // Voltage Chart
    const voltageCtx = document.getElementById('voltage-chart').getContext('2d');
    chartInstances.voltage = new Chart(voltageCtx, {
        type: 'line',
        data: {
            labels: timeLabels,
            datasets: [{
                data: [],
                borderColor: '#1a73e8',
                borderWidth: 2,
                fill: false,
                tension: 0.4
            }]
        },
        options: getChartOptions()
    });
    
    // Current Chart
    const currentCtx = document.getElementById('current-chart').getContext('2d');
    chartInstances.current = new Chart(currentCtx, {
        type: 'line',
        data: {
            labels: timeLabels,
            datasets: [{
                data: [],
                borderColor: '#1a73e8',
                borderWidth: 2,
                fill: false,
                tension: 0.4
            }]
        },
        options: getChartOptions()
    });
    
    // Power Chart
    const powerCtx = document.getElementById('power-chart').getContext('2d');
    chartInstances.power = new Chart(powerCtx, {
        type: 'line',
        data: {
            labels: timeLabels,
            datasets: [{
                data: [],
                borderColor: '#1a73e8',
                borderWidth: 2,
                fill: false,
                tension: 0.4
            }]
        },
        options: getChartOptions()
    });
    
    // Energy Chart
    const energyCtx = document.getElementById('energy-chart').getContext('2d');
    chartInstances.energy = new Chart(energyCtx, {
        type: 'line',
        data: {
            labels: timeLabels,
            datasets: [{
                data: [],
                borderColor: '#1a73e8',
                borderWidth: 2,
                fill: false,
                tension: 0.4
            }]
        },
        options: getChartOptions()
    });
    
    // Frequency Chart
    const frequencyCtx = document.getElementById('frequency-chart').getContext('2d');
    chartInstances.frequency = new Chart(frequencyCtx, {
        type: 'line',
        data: {
            labels: timeLabels,
            datasets: [{
                data: [],
                borderColor: '#1a73e8',
                borderWidth: 2,
                fill: false,
                tension: 0.4
            }]
        },
        options: getChartOptions()
    });
    
    // Power Factor Chart
    const powerFactorCtx = document.getElementById('power-factor-chart').getContext('2d');
    chartInstances.powerFactor = new Chart(powerFactorCtx, {
        type: 'line',
        data: {
            labels: timeLabels,
            datasets: [{
                data: [],
                borderColor: '#1a73e8',
                borderWidth: 2,
                fill: false,
                tension: 0.4
            }]
        },
        options: getChartOptions()
    });
}

function getChartOptions() {
    return {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                display: false
            },
            tooltip: {
                enabled: true
            }
        },
        scales: {
            x: {
                display: true,
                grid: {
                    display: false
                }
            },
            y: {
                display: true,
                grid: {
                    display: true
                },
                beginAtZero: false
            }
        },
        elements: {
            point: {
                radius: 3,
                hoverRadius: 5
            }
        }
    };
}

// Function to fetch real sensor data from your backend
async function fetchSensorData() {
    try {
        // Replace with your actual API endpoint
        const response = await fetch('/latest');
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const data = await response.json();
        
        return data;
    } catch (error) {
        console.error('Error fetching sensor data:', error);
        return null;
    }
}

function updateCharts(data) {
    if (!data) return;
    
    // Update charts with history data
    chartInstances.voltage.data.datasets[0].data = data.voltage.history;
    chartInstances.current.data.datasets[0].data = data.current.history;
    chartInstances.power.data.datasets[0].data = data.power.history;
    chartInstances.energy.data.datasets[0].data = data.energy.history;
    chartInstances.frequency.data.datasets[0].data = data.frequency.history;
    chartInstances.powerFactor.data.datasets[0].data = data.powerFactor.history;
    
    chartInstances.voltage.update();
    chartInstances.current.update();
    chartInstances.power.update();
    chartInstances.energy.update();
    chartInstances.frequency.update();
    chartInstances.powerFactor.update();
}

function updateTrendIndicator(elementId, trendValue) {
    const element = document.getElementById(elementId);
    const icon = element.querySelector('.trend-icon');
    const text = element.querySelector('span:not(.trend-icon)');

    icon.className = 'trend-icon';
    text.className = '';

    if (trendValue > 0) {
        icon.textContent = '↑';
        text.classList.add('trend-up');
        text.textContent = `Last 24 Hours +${Math.abs(trendValue)}%`;
    } else if (trendValue < 0) {
        icon.textContent = '↓';
        text.classList.add('trend-down');
        text.textContent = `Last 24 Hours -${Math.abs(trendValue)}%`;
    } else {
        icon.textContent = '';
        text.classList.add('trend-neutral');
        text.textContent = 'Last 24 Hours';
    }
}

async function updateDashboard() {
    const data = await fetchSensorData();
    
    if (data) {
        // Update current values
        document.getElementById('voltage-value').textContent = data.voltage.current + 'V';
        document.getElementById('current-value').textContent = data.current.current + 'A';
        document.getElementById('power-value').textContent = data.power.current + ' W';
        document.getElementById('energy-value').textContent = data.energy.current + 'kWh';
        document.getElementById('frequency-value').textContent = data.frequency.current + 'Hz';
        document.getElementById('power-factor-value').textContent = data.powerFactor.current;
        
        // Update trend values
        document.getElementById('voltage-trend-value').textContent = data.voltage.current + 'V';
        document.getElementById('current-trend-value').textContent = data.current.current + 'A';
        document.getElementById('power-trend-value').textContent = data.power.current + ' W';
        document.getElementById('energy-trend-value').textContent = data.energy.current + 'kWh';
        document.getElementById('frequency-trend-value').textContent = data.frequency.current + 'Hz';
        document.getElementById('power-factor-trend-value').textContent = data.powerFactor.current;
        
        // Update trend indicators
        updateTrendIndicator('voltage-trend', data.voltage.trend);
        updateTrendIndicator('current-trend', data.current.trend);
        updateTrendIndicator('power-trend', data.power.trend);
        updateTrendIndicator('energy-trend', data.energy.trend);
        updateTrendIndicator('frequency-trend', data.frequency.trend);
        updateTrendIndicator('power-factor-trend', data.powerFactor.trend);
        
        // Update charts
        updateCharts(data);
    }
}

// Initialize the dashboard
document.addEventListener('DOMContentLoaded', function() {
    initCharts();
    updateDashboard();
    setInterval(updateDashboard, 5000); // Update every 5 seconds
});









let powerChart, energyChart, historicalPowerChart, historicalEnergyChart;

function showTab(tab) {
  document.getElementById('live-tab').style.display = tab === 'live' ? 'block' : 'none';
  document.getElementById('historical-tab').style.display = tab === 'historical' ? 'block' : 'none';

  const tabs = document.querySelectorAll('.tab');
  tabs.forEach(btn => btn.classList.remove('active'));

  const selectedTab = tab === 'live' ? tabs[0] : tabs[1];
  selectedTab.classList.add('active');

  const underline = document.querySelector('.tabs-underline');
  underline.style.width = selectedTab.offsetWidth + 'px';
  underline.style.left = selectedTab.offsetLeft + 'px';
}

async function fetchLiveData() {
  try {
    const powerData = [];
    const energyData = [];

    powerChart.data.datasets[0].data = powerData;
    energyChart.data.datasets[0].data = energyData;

    powerChart.update();
    energyChart.update();

    const latestPower = powerData[powerData.length - 1];
    const latestEnergy = energyData[energyData.length - 1];

    document.getElementById("livePowerValue").textContent = `${latestPower} kW`;
    document.getElementById("liveEnergyValue").textContent = `${latestEnergy} kWh`;

    document.getElementById("livePowerChange").textContent = `Live`;
    document.getElementById("liveEnergyChange").textContent = `Live`;

  } catch (error) {
    console.error("Error fetching live data:", error);
  }
}

function generateDateLabels(startDate, endDate) {
  const labels = [];
  let current = new Date(startDate);
  const end = new Date(endDate);
  while (current <= end) {
    labels.push(current.toISOString().split('T')[0]);
    current.setDate(current.getDate() + 1);
  }
  return labels;
}


async function generateHistoricalData() {
    const start = document.getElementById("start-date").value;
    const end = document.getElementById("end-date").value;
  
    if (!start || !end) {
      alert("Please select both start and end dates.");
      return;
    }
  
    try {
      const response = await fetch(`/historical?start=${start}&end=${end}`);
      const result = await response.json();
  
      if (result.message) {
        alert(result.message);
        return;
      }
  
      const labels = result.labels;
      const powerData = result.power;
      const energyData = result.energy;
  
      if (historicalPowerChart) historicalPowerChart.destroy();
      if (historicalEnergyChart) historicalEnergyChart.destroy();
  
      const powerCtx = document.getElementById("historicalPowerChart").getContext("2d");
      const energyCtx = document.getElementById("historicalEnergyChart").getContext("2d");
  
      historicalPowerChart = new Chart(powerCtx, {
        type: "line",
        data: {
          labels: labels,
          datasets: [{
            label: "Power (kW)",
            data: powerData,
            borderColor: "#007bff",
            fill: false,
            tension: 0.4
          }]
        },

        
        options: {
          plugins: { legend: { display: false } },
          scales: {
            y: { display: false, grid: { display: false }, ticks: { display: false } },
            x: { display: true, grid: { display: false }, ticks: { display: true } }
          }
        }
      });
  
      
      historicalEnergyChart = new Chart(energyCtx, {
        type: "bar",
        data: {
          labels: labels,
          datasets: [{
            label: "Energy (kWh)",
            data: energyData,
            backgroundColor: "#007bff"
          }]
        },
        
        options: {
          plugins: { legend: { display: false } },
          scales: {
            y: { display: false, grid: { display: false }, ticks: { display: false } },
            x: { display: true, grid: { display: false }, ticks: { display: true } }
          }
        }
      });
     
      const latestPower = powerData[powerData.length - 1];
      const latestEnergy = energyData[energyData.length - 1];
  
  

      document.getElementById("histPowerValue").textContent = `${latestPower} kW`;
      document.getElementById("histPowerChange").textContent = `Today`;
      document.getElementById("histEnergyValue").textContent = `${latestEnergy} kWh`;
      document.getElementById("histEnergyChange").textContent = `Today`;

  
    } catch (error) {
      console.error("Error fetching historical data:", error);
      alert("Failed to load historical data.");
    }
  }
  

window.onload = function () {
  const powerCtx = document.getElementById('powerChart').getContext('2d');
  const energyCtx = document.getElementById('energyChart').getContext('2d');

  powerChart = new Chart(powerCtx, {
    type: 'line',
    data: {
      labels: [],
      datasets: [{ data: [], borderColor: '#007bff', tension: 0.4, fill: false }]
    },
    options: {
      plugins: { legend: { display: false } },
      scales: {
        y: { display: false, grid: { display: false }, ticks: { display: false } },
        x: { display: true, grid: { display: false }, ticks: { display: true } }
      }
    }
  });

  energyChart = new Chart(energyCtx, {
    type: 'bar',
    data: {
      labels: [],
      datasets: [{ data: [], backgroundColor: '#007bff' }]
    },
    options: {
      plugins: { legend: { display: false } },
      scales: {
        y: { display: false, grid: { display: false }, ticks: { display: false } },
        x: { display: true, grid: { display: false }, ticks: { display: true } }
      }
    }
  });

  const activeTab = document.querySelector('.tab.active');
  const underline = document.querySelector('.tabs-underline');
  underline.style.width = activeTab.offsetWidth + 'px';
  underline.style.left = activeTab.offsetLeft + 'px';
};



